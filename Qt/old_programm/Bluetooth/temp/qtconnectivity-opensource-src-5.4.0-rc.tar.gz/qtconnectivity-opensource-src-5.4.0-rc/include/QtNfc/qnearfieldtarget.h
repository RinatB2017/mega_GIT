#include "../../src/nfc/qnearfieldtarget.h"
