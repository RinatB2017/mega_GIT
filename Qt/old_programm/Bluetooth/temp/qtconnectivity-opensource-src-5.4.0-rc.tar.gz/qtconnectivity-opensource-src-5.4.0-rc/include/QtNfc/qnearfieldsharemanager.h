#include "../../src/nfc/qnearfieldsharemanager.h"
