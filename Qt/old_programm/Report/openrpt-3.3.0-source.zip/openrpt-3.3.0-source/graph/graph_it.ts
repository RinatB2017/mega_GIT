<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="it">
<defaultcodec></defaultcodec>
<context>
    <name>GraphWindow</name>
    <message>
        <location filename="graphwindow.ui" line="32"/>
        <source>Graph Window</source>
        <translation>Finestra del Grafico</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="108"/>
        <source>Labels</source>
        <translation>Etichette</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="120"/>
        <source>Data:</source>
        <translation>Dati:</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="130"/>
        <source>Title:</source>
        <translation>Titolo:</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="140"/>
        <source>Value:</source>
        <translation>Valore:</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="189"/>
        <source>Padding (in pixels)</source>
        <translation>Bordo (in pixel)</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="201"/>
        <source>Vertical:</source>
        <translation>Verticale:</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="211"/>
        <source>Horizontal:</source>
        <translation>Orizzontale:</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="254"/>
        <source>Value Range</source>
        <translation>Intervallo Valori</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="266"/>
        <source>Max:</source>
        <translation>Max:</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="276"/>
        <source>Min:</source>
        <translation>Min:</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="328"/>
        <source>Clear All</source>
        <translation>Cancella Tutto</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="339"/>
        <source>Graph Style</source>
        <translation>Stile del Grafico</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="351"/>
        <source>Bars</source>
        <translation>Barre</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="361"/>
        <source>Lines</source>
        <translation>Linee</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="368"/>
        <source>Points</source>
        <translation>Punti</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="394"/>
        <source>Number of Sets:</source>
        <translation>Numero di Set:</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="419"/>
        <source>Number of References:</source>
        <translation>Numero di Referenze:</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="461"/>
        <source>Label</source>
        <translation>Etichetta</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="486"/>
        <source>Populate with SQL</source>
        <translation>Popola con SQL</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="525"/>
        <source>Execute</source>
        <translation>Esegui</translation>
    </message>
</context>
</TS>
