#include "../../../../../src/nfc/qnearfieldmanager_simulator_p.h"
