#include "../../../../../src/nfc/qndefrecord_p.h"
