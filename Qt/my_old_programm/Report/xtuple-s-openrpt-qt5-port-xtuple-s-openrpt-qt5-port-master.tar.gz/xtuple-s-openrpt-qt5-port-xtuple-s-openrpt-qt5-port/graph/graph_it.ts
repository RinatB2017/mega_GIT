<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="it">
<context>
    <name>GraphWindow</name>
    <message>
        <location filename="graphwindow.ui" line="30"/>
        <source>Graph Window</source>
        <translation>Finestra del Grafico</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="102"/>
        <source>Labels</source>
        <translation>Etichette</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="114"/>
        <source>Data:</source>
        <translation>Dati:</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="127"/>
        <source>Title:</source>
        <translation>Titolo:</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="140"/>
        <source>Value:</source>
        <translation>Valore:</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="186"/>
        <source>Padding (in pixels)</source>
        <translation>Bordo (in pixel)</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="198"/>
        <source>Vertical:</source>
        <translation>Verticale:</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="211"/>
        <source>Horizontal:</source>
        <translation>Orizzontale:</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="253"/>
        <source>Value Range</source>
        <translation>Intervallo Valori</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="265"/>
        <source>Max:</source>
        <translation>Max:</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="278"/>
        <source>Min:</source>
        <translation>Min:</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="329"/>
        <source>Clear All</source>
        <translation>Cancella Tutto</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="340"/>
        <source>Graph Style</source>
        <translation>Stile del Grafico</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="352"/>
        <source>Bars</source>
        <translation>Barre</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="362"/>
        <source>Lines</source>
        <translation>Linee</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="369"/>
        <source>Points</source>
        <translation>Punti</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="393"/>
        <source>Number of Sets:</source>
        <translation>Numero di Set:</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="419"/>
        <source>Number of References:</source>
        <translation>Numero di Referenze:</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="462"/>
        <source>Label</source>
        <translation>Etichetta</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="485"/>
        <source>Populate with SQL</source>
        <translation>Popola con SQL</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="524"/>
        <source>Execute</source>
        <translation>Esegui</translation>
    </message>
</context>
</TS>
