#include "../../../../../src/nfc/qnearfieldtagtype2_p.h"
