#include "../../../../../src/nfc/qllcpsocket_p.h"
