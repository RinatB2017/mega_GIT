
#include <windows.h>
#include <windowsx.h>

#pragma hdrstop

#include <gl\gl.h>
#include <gl\glu.h>
#include <gl\glaux.h>

#include <stdio.h>

//#include "3dtvlightres.h"

//---------------------------------------------------------------------------
// Defines
#define FRAME_RATE	7

//---------------------------------------------------------------------------
// Variable
static	HGLRC hRC;
static	HDC hDC;

BOOL	keys[256];
GLfloat	Xrot,Yrot,Zrot;
GLuint	texture[12];
GLfloat light_diffuse[] = {1.0, 1.0, 1.0, 1.0};
GLfloat light_position[] = { 1.0, 1.0, 1.0, 0.0 };

BOOL	lp;

BOOL	Fm;
int		LoopCount;
GLint	TexNum;

// Const
const	int	FULLSCREEN = 1;		// 1 - full screen, 0 - window

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM  wParam,LPARAM  lParam);
void SetDCPixelFormat(HDC hDC);
GLvoid Resize(GLsizei Width, GLsizei Height);
GLvoid Initial(GLsizei Width, GLsizei Height, HWND hWnd);
void Draw(void);

// --------------------------------------------------------------------------

GLvoid Resize(GLsizei Width, GLsizei Height)
{
	if(Height==0)
		Height = 1;
	glViewport(0, 0, Width, Height);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	gluPerspective(45.0f, (GLfloat)Width / (GLfloat)Height, 0.1f, 100.0f);

	glMatrixMode(GL_MODELVIEW);
}

GLvoid LoadGLTexture(GLvoid)
{
	char buffer[30];
	int i;
	AUX_RGBImageRec *txtre[12];

	for(i=1; i<=12; i++)
	{
		sprintf(buffer,"./Images/0%d.bmp",i);
		txtre[i-1] = auxDIBImageLoad(buffer);

		glBindTexture (GL_TEXTURE_2D, i);
		glPixelStorei (GL_UNPACK_ALIGNMENT, 1);
		glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexEnvf (GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
		glTexImage2D(GL_TEXTURE_2D, 0, 3, txtre[i-1]->sizeX, txtre[i-1]->sizeY, 0, GL_RGB, GL_UNSIGNED_BYTE, txtre[i-1]->data);
	}
}

GLvoid Initial(GLsizei Width, GLsizei Height, HWND hWnd)
{
	LoadGLTexture();
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);

	glClearDepth(1.0);
	glDepthFunc(GL_LESS);
	glEnable(GL_DEPTH_TEST);

	glShadeModel(GL_SMOOTH);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	gluPerspective(45.0f, (GLfloat)Width / (GLfloat)Height, 0.1f, 100.0f);
	glMatrixMode(GL_MODELVIEW);

	glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
	glLightfv(GL_LIGHT0, GL_POSITION, light_position);

	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);

	lp = TRUE;
	TexNum = 1;
}

void Draw(void)
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();

	glTranslatef(0.0f, 0.0f, -5.0f);

	glRotatef(Xrot, 1.0f, 0.0f, 0.0f);
	glRotatef(Yrot, 0.0f, 1.0f, 0.0f);
	glRotatef(Zrot, 0.0f, 0.0f, 1.0f);

	glEnable (GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D,TexNum);

	glBegin(GL_QUADS);
		glNormal3f(0.0, 0.0, -1.0);
		glTexCoord2f(0.0f, 0.0f);	glVertex3f(1.0f, 1.0f, -1.0f);
		glTexCoord2f(0.0f, 1.0f);	glVertex3f(1.0f, -1.0f, -1.0f);
		glTexCoord2f(1.0f, 1.0f);	glVertex3f(-1.0f, -1.0f, -1.0f);
		glTexCoord2f(1.0f, 0.0f);	glVertex3f(-1.0f, 1.0f, -1.0f);

		glNormal3f(0.0, 0.0, 1.0);
		glTexCoord2f(0.0f, 0.0f);	glVertex3f(1.0f, 1.0f, 1.0f);
		glTexCoord2f(0.0f, 1.0f);	glVertex3f(1.0f, -1.0f, 1.0f);
		glTexCoord2f(1.0f, 1.0f);	glVertex3f(-1.0f, -1.0f, 1.0f);
		glTexCoord2f(1.0f, 0.0f);	glVertex3f(-1.0f, 1.0f, 1.0f);

		glNormal3f(1.0, 0.0, 0.0);
		glTexCoord2f(0.0f, 0.0f);	glVertex3f(1.0f, 1.0f, 1.0f);
		glTexCoord2f(0.0f, 1.0f);	glVertex3f(1.0f, 1.0f, -1.0f);
		glTexCoord2f(1.0f, 1.0f);	glVertex3f(1.0f, -1.0f, -1.0f);
		glTexCoord2f(1.0f, 0.0f);	glVertex3f(1.0f, -1.0f, 1.0f);

		glNormal3f(-1.0, 0.0, 0.0);
		glTexCoord2f(0.0f, 0.0f);	glVertex3f(-1.0f, 1.0f, -1.0f);
		glTexCoord2f(0.0f, 1.0f);	glVertex3f(-1.0f, -1.0f, -1.0f);
		glTexCoord2f(1.0f, 1.0f);	glVertex3f(-1.0f, -1.0f, 1.0f);
		glTexCoord2f(1.0f, 0.0f);	glVertex3f(-1.0f, 1.0f, 1.0f);

		glNormal3f(0.0, 1.0, 0.0);
		glTexCoord2f(0.0f, 0.0f);	glVertex3f(-1.0f, 1.0f, -1.0f);
		glTexCoord2f(0.0f, 1.0f);	glVertex3f(1.0f, 1.0f, -1.0f);
		glTexCoord2f(1.0f, 1.0f);	glVertex3f(1.0f, 1.0f, 1.0f);
		glTexCoord2f(1.0f, 0.0f);	glVertex3f(-1.0f, 1.0f, 1.0f);

		glNormal3f(0.0, -1.0, 0.0);
		glTexCoord2f(0.0f, 0.0f);	glVertex3f(-1.0f, -1.0f, -1.0f);
		glTexCoord2f(0.0f, 1.0f);	glVertex3f(1.0f, -1.0f, -1.0f);
		glTexCoord2f(1.0f, 1.0f);	glVertex3f(1.0f, -1.0f, 1.0f);
		glTexCoord2f(1.0f, 0.0f);	glVertex3f(-1.0f, -1.0f, 1.0f);
	glEnd();

	glDisable(GL_TEXTURE_2D);

	Xrot += 0.1f;
	Yrot += 0.2f;
	Zrot += 0.25f;

	if(Fm)
	{
		TexNum++;
		if(TexNum == 13)
			TexNum = 1;
		Fm = FALSE;
	}

}

int APIENTRY WinMain(   HINSTANCE       hInst, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	MSG             msg;   
	WNDCLASS        wc;            
	HWND            hWnd;
//	HANDLE hAccelTable;


	wc.style                = CS_HREDRAW | CS_VREDRAW | CS_OWNDC;
	wc.lpfnWndProc          = (WNDPROC) WndProc;
	wc.cbClsExtra           = 0;
	wc.cbWndExtra           = 0;
	wc.hInstance            = hInst;
	wc.hIcon                = NULL;
	wc.hCursor              = LoadCursor(NULL, IDC_ARROW);

	wc.hbrBackground        = NULL;         
	
//	wc.lpszMenuName         = MAKEINTRESOURCE(IDMAINMENU);
	wc.lpszMenuName         = NULL;
	wc.lpszClassName        = "3DTV";

//	hAccelTable = LoadAccelerators(hInst,MAKEINTRESOURCE(IDACCEL));

	if(RegisterClass(&wc) == 0)
		return FALSE;

	if(FULLSCREEN==0)
	{
		hWnd = CreateWindow(
					"3DTV",
					"3DTV",
					
					WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN | WS_CLIPSIBLINGS,
					50, 50,
					500, 400,
					NULL,
					NULL,
					hInst,
					NULL);
	} else {
		hWnd = CreateWindow(
					"3DTV",
					"3DTV",
					
					WS_POPUP | WS_CLIPCHILDREN | WS_CLIPSIBLINGS,
					0, 0,
					800, 600,
					NULL,
					NULL,
					hInst,
					NULL);
	}

	if(hWnd == NULL)
		return FALSE;

	if(FULLSCREEN==1)
	{	
		DEVMODE dmScreenSettings;

		memset(&dmScreenSettings, 0, sizeof(DEVMODE));
		dmScreenSettings.dmSize			= sizeof(DEVMODE);
		dmScreenSettings.dmPelsWidth	= 800;
		dmScreenSettings.dmPelsHeight	= 600;
		dmScreenSettings.dmFields		= DM_PELSWIDTH | DM_PELSHEIGHT;
		ChangeDisplaySettings(&dmScreenSettings, CDS_FULLSCREEN);
	}

	ShowWindow(hWnd,SW_SHOW);
	UpdateWindow(hWnd);
	SetFocus(hWnd);

	while(1)
	{
		while( PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE))
		{
			if( GetMessage(&msg, NULL, 0, 0) ) 
			{
//				if (!TranslateAccelerator(msg.hwnd,hAccelTable,&msg)) {
					TranslateMessage(&msg);
					DispatchMessage(&msg);
//				}
			}
			else
			{
				return TRUE;
			}
		}

		LoopCount++;
		if(LoopCount >= FRAME_RATE)
		{
			Fm = TRUE;
			LoopCount = 0;
		}

		Draw();
		SwapBuffers(hDC);
	}	
}

LRESULT CALLBACK WndProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	RECT Screen;
	GLuint PixelFormat;

	static PIXELFORMATDESCRIPTOR pfd =
	{
		sizeof(PIXELFORMATDESCRIPTOR),		// ������
		1,									// ������ ?
		PFD_DRAW_TO_WINDOW|					// format must support Window
		PFD_SUPPORT_OPENGL|					// format must support OpenGL
		PFD_DOUBLEBUFFER,					// must support double buffer
		PFD_TYPE_RGBA,						// ��������� RGBA ������
		16,									// 16Bit color depth
		0, 0, 0, 0, 0, 0,					// Color bits ignored ?
		0,									// No Alpha buffer
		0,									// shift bit ignored
		0,									// no accumulation buffer
		0, 0, 0, 0,							// accumulation buffer bits ignored
		16,									// 16bit z-buffer (depth buffer)
		0,									// no stencil buffer
		0,									// no auxiliary buffer
		PFD_MAIN_PLANE,						// main drawing layer
		0,									// reserved
		0, 0, 0								// layer mask ignored
	};

	switch(msg)
	{
	case WM_CREATE:
		hDC = GetDC(hWnd);
		PixelFormat = ChoosePixelFormat(hDC, &pfd);

		if(!PixelFormat){
			MessageBox(0, "Can't find suitable PixelFormat","Error", MB_OK|MB_ICONERROR);
			PostQuitMessage(0);
			break;
		}

		if(!SetPixelFormat(hDC, PixelFormat, &pfd)) {
			MessageBox(0, "Can't set The PixelFormat","Error",MB_OK|MB_ICONERROR);
			PostQuitMessage(0);
			break;
		}
		hRC = wglCreateContext(hDC);
		if(!hRC) {
			MessageBox(0, "Can't Create Render Device Context","Error",MB_OK|MB_ICONERROR);
			PostQuitMessage(0);
			break;
		}
		if(!wglMakeCurrent(hDC, hRC)) {
			MessageBox(0, "Can't set current Render Device Context","Error",MB_OK|MB_ICONERROR);
			PostQuitMessage(0);
			break;
		}

		GetClientRect(hWnd, &Screen);
		Initial(Screen.right, Screen.bottom, hWnd);
		break;
	case WM_CLOSE:
	case WM_DESTROY:
		ChangeDisplaySettings(NULL, 0);

		wglMakeCurrent(hDC, NULL);
		wglDeleteContext(hRC);
		ReleaseDC(hWnd, hDC);

		PostQuitMessage(0);
		break;
	case WM_KEYDOWN:
		if(wParam == VK_ESCAPE)
			SendMessage(hWnd, WM_DESTROY, wParam, lParam);
		if(wParam == 'L') {
			if(lp == TRUE) {
				glDisable(GL_LIGHTING);
				glDisable(GL_LIGHT0);
				lp = FALSE;
			} else {
				glEnable(GL_LIGHTING);
				glEnable(GL_LIGHT0);
				lp = TRUE;
			}
		}
		break;
	case WM_SIZE:
		Resize(LOWORD(lParam), HIWORD(lParam));
		break;
	default:
		return( DefWindowProc(hWnd, msg, wParam, lParam));
	}
	return(0);
}

