#include "../../../../../src/nfc/qnearfieldmanager_emulator_p.h"
