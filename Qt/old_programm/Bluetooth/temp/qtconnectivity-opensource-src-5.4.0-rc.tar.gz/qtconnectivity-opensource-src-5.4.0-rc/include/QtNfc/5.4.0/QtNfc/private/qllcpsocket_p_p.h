#include "../../../../../src/nfc/qllcpsocket_p_p.h"
