#include "../../../../../src/nfc/qnearfieldsharemanagerimpl_p.h"
