#include "../../src/nfc/qndefmessage.h"
