#include "../../../../../src/nfc/qnearfieldmanager_p.h"
