#include "../../src/bluetooth/qbluetoothglobal.h"
