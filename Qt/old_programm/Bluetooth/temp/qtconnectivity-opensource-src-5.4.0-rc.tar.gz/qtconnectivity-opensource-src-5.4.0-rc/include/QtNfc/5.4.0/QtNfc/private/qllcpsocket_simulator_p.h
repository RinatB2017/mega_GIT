#include "../../../../../src/nfc/qllcpsocket_simulator_p.h"
