#include "../../../../../src/nfc/qnearfieldtagtype4_p.h"
