#include "../../../../../src/nfc/qnearfieldmanager_qnx_p.h"
