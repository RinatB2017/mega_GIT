<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="it">
<defaultcodec></defaultcodec>
<context>
    <name>ReportWriterWindow</name>
    <message>
        <location filename="reportwriterwindow.cpp" line="50"/>
        <source>OpenMFG: Report Writer</source>
        <translation>OpenRPT: Editor dei report</translation>
    </message>
    <message>
        <location filename="reportwriterwindow.cpp" line="61"/>
        <source>E&amp;xit</source>
        <translation>&amp;Esci</translation>
    </message>
    <message>
        <location filename="reportwriterwindow.cpp" line="72"/>
        <source>&amp;Windows</source>
        <translation>&amp;Finestra</translation>
    </message>
    <message>
        <location filename="reportwriterwindow.cpp" line="147"/>
        <source>Version</source>
        <translation>Versione</translation>
    </message>
    <message>
        <location filename="reportwriterwindow.cpp" line="166"/>
        <source>%1 - %2 on %3/%4 AS %5</source>
        <translation>%1 - %2 di %3/%4 come %5</translation>
    </message>
    <message>
        <location filename="reportwriterwindow.cpp" line="182"/>
        <source>&amp;Cascade</source>
        <translation>&amp;Cascata</translation>
    </message>
    <message>
        <location filename="reportwriterwindow.cpp" line="183"/>
        <source>&amp;Tile</source>
        <translation>&amp;Titolo</translation>
    </message>
</context>
</TS>
