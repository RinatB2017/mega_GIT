#include "../../src/nfc/qndefnfcsmartposterrecord.h"
