#include "../../src/bluetooth/qbluetoothtransferrequest.h"
