#include "gifanimationdemowidget.h"
#include "ui_gifanimationdemowidget.h"

GIFAnimationDemoWidget::GIFAnimationDemoWidget( QWidget* parent ) :
    QWidget( parent ), ui( new Ui::GIFAnimationDemoWidget ), m_movie( ":/loading.gif" ) {
    ui->setupUi( this );

    ui->lbMovie->setMovie( &m_movie );

    connect( ui->bnStart, SIGNAL( clicked( bool ) ), &m_movie, SLOT( start() ) );
    connect( ui->bnStop, SIGNAL( clicked( bool ) ), &m_movie, SLOT( stop() ) );
}

GIFAnimationDemoWidget::~GIFAnimationDemoWidget() {
    delete ui;
}
