#ifndef FIGURETYPE_H
# define FIGURETYPE_H

enum FigureType { None, Rect, Rhomb };

#endif // FIGURETYPE_H
