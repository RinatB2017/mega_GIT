#include "../../src/bluetooth/qlowenergydescriptor.h"
