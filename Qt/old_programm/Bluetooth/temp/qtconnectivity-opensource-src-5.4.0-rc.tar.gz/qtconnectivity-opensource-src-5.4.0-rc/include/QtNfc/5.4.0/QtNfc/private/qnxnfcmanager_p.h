#include "../../../../../src/nfc/qnx/qnxnfcmanager_p.h"
