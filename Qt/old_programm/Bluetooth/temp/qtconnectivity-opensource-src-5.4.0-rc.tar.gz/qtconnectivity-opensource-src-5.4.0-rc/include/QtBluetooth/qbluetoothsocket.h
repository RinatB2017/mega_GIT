#include "../../src/bluetooth/qbluetoothsocket.h"
