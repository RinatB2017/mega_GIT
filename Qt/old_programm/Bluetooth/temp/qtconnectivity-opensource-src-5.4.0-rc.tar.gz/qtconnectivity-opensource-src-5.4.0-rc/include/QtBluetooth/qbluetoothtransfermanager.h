#include "../../src/bluetooth/qbluetoothtransfermanager.h"
