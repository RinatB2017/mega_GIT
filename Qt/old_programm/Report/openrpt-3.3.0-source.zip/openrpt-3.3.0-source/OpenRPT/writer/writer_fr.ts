<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="fr">
<context>
    <name>ReportWriterWindow</name>
    <message>
        <location filename="reportwriterwindow.cpp" line="50"/>
        <source>OpenMFG: Report Writer</source>
        <translation type="obsolete">OpenRPT: Editeur de rapports</translation>
    </message>
    <message>
        <location filename="reportwriterwindow.cpp" line="63"/>
        <source>E&amp;xit</source>
        <translation>&amp;Quitter</translation>
    </message>
    <message>
        <location filename="reportwriterwindow.cpp" line="76"/>
        <source>&amp;Windows</source>
        <translation>&amp;Fenêtres</translation>
    </message>
    <message>
        <location filename="reportwriterwindow.cpp" line="157"/>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <location filename="reportwriterwindow.cpp" line="175"/>
        <source>%1 - %2 on %3/%4 AS %5</source>
        <translation>%1 - %2 sur %3/%4 en tant que %5</translation>
    </message>
    <message>
        <location filename="reportwriterwindow.cpp" line="191"/>
        <source>&amp;Cascade</source>
        <translation>&amp;Cascade</translation>
    </message>
    <message>
        <location filename="reportwriterwindow.cpp" line="192"/>
        <source>&amp;Tile</source>
        <translation>&amp;Mosaique</translation>
    </message>
</context>
</TS>
