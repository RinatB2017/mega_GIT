#include "../../src/nfc/qnearfieldmanager.h"
