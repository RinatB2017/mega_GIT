/* --- The following code comes from c:\program files\lcc\lib\wizard\stddef.tpl. */
// This are the definitions for all symbols used in menus or string.
#define IDACCEL 100
#define IDM_NEW 200
#define IDM_OPEN 210
#define IDM_SAVE 220
#define IDM_SAVEAS 230
#define IDM_CLOSE 240
#define IDM_PRINT 250
#define IDM_PAGESETUP 260
#define IDM_EXIT 300
#define IDM_ABOUT 500
#define IDMAINMENU 600
#define IDAPPLICON 710
#define IDAPPLCURSOR 810
#define IDS_FILEMENU 2000
#define IDS_HELPMENU 2010
#define IDS_SYSMENU 2030
#define IDM_STATUSBAR 3000
