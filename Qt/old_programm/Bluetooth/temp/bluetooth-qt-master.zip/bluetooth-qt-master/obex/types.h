#ifndef _OBEX_TYPES_H_
#define _OBEX_TYPES_H_

#include <QtCore/QMap>
#include <QtCore/QVariantMap>
#include <QtCore/QString>

typedef QList<QVariantMap> QVariantMapList;
Q_DECLARE_METATYPE(QVariantMapList)

#endif
