#include "../../../../../src/nfc/qnearfieldtagtype3_p.h"
