#include "../../../../../src/nfc/qnearfieldtagtype1_p.h"
