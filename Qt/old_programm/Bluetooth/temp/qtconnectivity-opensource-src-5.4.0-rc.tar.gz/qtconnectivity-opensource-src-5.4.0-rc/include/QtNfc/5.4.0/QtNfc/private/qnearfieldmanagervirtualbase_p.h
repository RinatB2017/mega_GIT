#include "../../../../../src/nfc/qnearfieldmanagervirtualbase_p.h"
