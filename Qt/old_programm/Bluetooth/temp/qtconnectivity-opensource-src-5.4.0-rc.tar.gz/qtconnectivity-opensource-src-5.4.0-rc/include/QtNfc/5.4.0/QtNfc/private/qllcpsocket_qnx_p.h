#include "../../../../../src/nfc/qllcpsocket_qnx_p.h"
