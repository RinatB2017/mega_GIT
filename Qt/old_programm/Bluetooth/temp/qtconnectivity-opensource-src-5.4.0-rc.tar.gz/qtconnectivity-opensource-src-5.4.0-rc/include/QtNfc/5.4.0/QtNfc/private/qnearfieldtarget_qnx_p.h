#include "../../../../../src/nfc/qnearfieldtarget_qnx_p.h"
