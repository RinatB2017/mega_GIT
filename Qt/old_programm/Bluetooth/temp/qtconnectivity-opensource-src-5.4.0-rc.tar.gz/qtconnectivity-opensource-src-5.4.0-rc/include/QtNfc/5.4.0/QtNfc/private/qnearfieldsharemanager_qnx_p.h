#include "../../../../../src/nfc/qnearfieldsharemanager_qnx_p.h"
