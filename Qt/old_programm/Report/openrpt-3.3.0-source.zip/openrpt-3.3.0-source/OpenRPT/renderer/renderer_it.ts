<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="it">
<defaultcodec></defaultcodec>
<context>
    <name>PreviewDialog</name>
    <message>
        <location filename="previewdialog.cpp" line="46"/>
        <source>Print Preview</source>
        <translation>Anteprima di Stampa</translation>
    </message>
    <message>
        <location filename="previewdialog.cpp" line="63"/>
        <source>Print</source>
        <translation>Stampa</translation>
    </message>
    <message>
        <location filename="previewdialog.cpp" line="64"/>
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
    <message>
        <location filename="previewdialog.cpp" line="53"/>
        <source>Zoom in</source>
        <translation>Ingrandisci</translation>
    </message>
    <message>
        <location filename="previewdialog.cpp" line="58"/>
        <source>Zoom out</source>
        <translation>Riduci</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="openreports.cpp" line="1778"/>
        <source>Missing Report Parameter</source>
        <translation>Parametro del Report mancance</translation>
    </message>
    <message>
        <location filename="openreports.cpp" line="1778"/>
        <source>Enter in a value for the parameter &quot;%1&quot;:</source>
        <translation>Inserisci il valore per il parametro &quot;%1&quot;:</translation>
    </message>
    <message>
        <location filename="openreports_wrapper.cpp" line="541"/>
        <source>Report Definition Not Found</source>
        <translation>Definizione del Report non trovata</translation>
    </message>
    <message>
        <location filename="openreports_wrapper.cpp" line="544"/>
        <source>The report definition for this report, &quot;%1&quot; cannot be found.
Please contact your Systems Administrator and report this issue.</source>
        <translation>Impossibile trovare la definizione del report &quot;%1&quot;.
Contatta l&apos;Amministratore del sistema riportando questo messaggio.</translation>
    </message>
    <message>
        <location filename="openreports_wrapper.cpp" line="546"/>
        <source>Unknown Error</source>
        <translation>Incontrato Errore Sconosciuto</translation>
    </message>
    <message>
        <location filename="openreports_wrapper.cpp" line="548"/>
        <source>An unknown error was encountered while processing your request.
Please contact your Systems Administrator and report this issue.</source>
        <translation>Durante l&apos;esecuzione del processo richiesto è stato riscontrato un errore sconosciuto.
Contatta l&apos;Amministratore di Sistema e riportaa questo messaggio.</translation>
    </message>
</context>
</TS>
