#include "../../../../../src/nfc/qnx/qnxnfcsharemanager_p.h"
