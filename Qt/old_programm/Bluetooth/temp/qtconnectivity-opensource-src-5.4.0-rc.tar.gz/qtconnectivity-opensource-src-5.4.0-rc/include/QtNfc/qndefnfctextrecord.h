#include "../../src/nfc/qndefnfctextrecord.h"
