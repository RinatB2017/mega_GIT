<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="es_AR">
<context>
    <name>ReportWriterWindow</name>
    <message>
        <location filename="reportwriterwindow.cpp" line="63"/>
        <source>E&amp;xit</source>
        <translation>&amp;Salir</translation>
    </message>
    <message>
        <location filename="reportwriterwindow.cpp" line="76"/>
        <source>&amp;Windows</source>
        <translation>&amp;Ventanas</translation>
    </message>
    <message>
        <location filename="reportwriterwindow.cpp" line="157"/>
        <source>Version</source>
        <translation></translation>
    </message>
    <message>
        <location filename="reportwriterwindow.cpp" line="175"/>
        <source>%1 - %2 on %3/%4 AS %5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="reportwriterwindow.cpp" line="191"/>
        <source>&amp;Cascade</source>
        <translation>&amp;Cascada</translation>
    </message>
    <message>
        <location filename="reportwriterwindow.cpp" line="192"/>
        <source>&amp;Tile</source>
        <translation>&amp;Título</translation>
    </message>
</context>
</TS>
