<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="ru">
<defaultcodec></defaultcodec>
<context>
    <name>ReportWriterWindow</name>
    <message>
        <location filename="reportwriterwindow.cpp" line="50"/>
        <source>OpenMFG: Report Writer</source>
        <translation>OpenRPT: Редактор Отчетов</translation>
    </message>
    <message>
        <location filename="reportwriterwindow.cpp" line="61"/>
        <source>E&amp;xit</source>
        <translation>Вы&amp;ход</translation>
    </message>
    <message>
        <location filename="reportwriterwindow.cpp" line="72"/>
        <source>&amp;Windows</source>
        <translation>&amp;Окна</translation>
    </message>
    <message>
        <location filename="reportwriterwindow.cpp" line="147"/>
        <source>Version</source>
        <translation>Версия</translation>
    </message>
    <message>
        <location filename="reportwriterwindow.cpp" line="166"/>
        <source>%1 - %2 on %3/%4 AS %5</source>
        <translation>%1 - %2 в %3/%4 как %5</translation>
    </message>
    <message>
        <location filename="reportwriterwindow.cpp" line="182"/>
        <source>&amp;Cascade</source>
        <translation>&amp;Каскадом</translation>
    </message>
    <message>
        <location filename="reportwriterwindow.cpp" line="183"/>
        <source>&amp;Tile</source>
        <translation>&amp;Плиткой</translation>
    </message>
</context>
</TS>
