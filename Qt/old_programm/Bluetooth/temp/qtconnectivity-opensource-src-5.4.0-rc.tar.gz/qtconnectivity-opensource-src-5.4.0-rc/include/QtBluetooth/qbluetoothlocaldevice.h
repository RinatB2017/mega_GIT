#include "../../src/bluetooth/qbluetoothlocaldevice.h"
