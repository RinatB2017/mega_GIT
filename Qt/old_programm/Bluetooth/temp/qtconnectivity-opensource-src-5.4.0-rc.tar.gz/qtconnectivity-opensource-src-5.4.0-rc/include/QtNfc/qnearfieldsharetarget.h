#include "../../src/nfc/qnearfieldsharetarget.h"
