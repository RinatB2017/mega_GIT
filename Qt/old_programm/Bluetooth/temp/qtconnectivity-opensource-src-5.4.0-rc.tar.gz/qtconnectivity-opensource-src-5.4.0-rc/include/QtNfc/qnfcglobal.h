#include "../../src/nfc/qnfcglobal.h"
