#include "../../src/bluetooth/qlowenergycharacteristic.h"
