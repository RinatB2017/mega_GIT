#include "../../../../../src/nfc/qndefnfcsmartposterrecord_p.h"
