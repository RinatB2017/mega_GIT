#include "../../src/nfc/qndefnfcurirecord.h"
