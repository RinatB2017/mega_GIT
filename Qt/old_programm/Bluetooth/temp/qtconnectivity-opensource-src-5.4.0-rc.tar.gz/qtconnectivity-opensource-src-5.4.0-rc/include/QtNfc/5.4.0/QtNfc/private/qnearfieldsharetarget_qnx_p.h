#include "../../../../../src/nfc/qnearfieldsharetarget_qnx_p.h"
