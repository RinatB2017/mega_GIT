<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="it">
<context>
    <name>ReportWriterWindow</name>
    <message>
        <source>OpenMFG: Report Writer</source>
        <translation type="obsolete">OpenRPT: Editor dei report</translation>
    </message>
    <message>
        <location filename="reportwriterwindow.cpp" line="63"/>
        <source>E&amp;xit</source>
        <translation>&amp;Esci</translation>
    </message>
    <message>
        <location filename="reportwriterwindow.cpp" line="76"/>
        <source>&amp;Windows</source>
        <translation>&amp;Finestra</translation>
    </message>
    <message>
        <location filename="reportwriterwindow.cpp" line="157"/>
        <source>Version</source>
        <translation>Versione</translation>
    </message>
    <message>
        <location filename="reportwriterwindow.cpp" line="176"/>
        <source>%1 - %2 on %3/%4 AS %5</source>
        <translation>%1 - %2 di %3/%4 come %5</translation>
    </message>
    <message>
        <location filename="reportwriterwindow.cpp" line="192"/>
        <source>&amp;Cascade</source>
        <translation>&amp;Cascata</translation>
    </message>
    <message>
        <location filename="reportwriterwindow.cpp" line="193"/>
        <source>&amp;Tile</source>
        <translation>&amp;Titolo</translation>
    </message>
</context>
</TS>
