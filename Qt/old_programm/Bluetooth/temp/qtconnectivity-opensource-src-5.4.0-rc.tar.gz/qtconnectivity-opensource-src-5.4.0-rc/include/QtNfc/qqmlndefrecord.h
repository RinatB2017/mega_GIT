#include "../../src/nfc/qqmlndefrecord.h"
