<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="ru">
<defaultcodec></defaultcodec>
<context>
    <name>GraphWindow</name>
    <message>
        <location filename="graphwindow.ui" line="32"/>
        <source>Graph Window</source>
        <translation>Окно Графика</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="108"/>
        <source>Labels</source>
        <translation>Метки</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="120"/>
        <source>Data:</source>
        <translation>Данные:</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="130"/>
        <source>Title:</source>
        <translation>Заголовок:</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="140"/>
        <source>Value:</source>
        <translation>Значение:</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="189"/>
        <source>Padding (in pixels)</source>
        <translation>Плотность (в пикселях)</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="201"/>
        <source>Vertical:</source>
        <translation>Вертикально:</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="211"/>
        <source>Horizontal:</source>
        <translation>Горизонтально:</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="254"/>
        <source>Value Range</source>
        <translation>Диапазон Значений</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="266"/>
        <source>Max:</source>
        <translation>Макс:</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="276"/>
        <source>Min:</source>
        <translation>Мин:</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="328"/>
        <source>Clear All</source>
        <translation>Очистить Все</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="339"/>
        <source>Graph Style</source>
        <translation>Стиль Графика</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="351"/>
        <source>Bars</source>
        <translation>Столбцы</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="361"/>
        <source>Lines</source>
        <translation>Строк</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="368"/>
        <source>Points</source>
        <translation>Точек</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="394"/>
        <source>Number of Sets:</source>
        <translation>Количество Наборов:</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="419"/>
        <source>Number of References:</source>
        <translation>Количество Указаний:</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="461"/>
        <source>Label</source>
        <translation>Метка</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="486"/>
        <source>Populate with SQL</source>
        <translation>Наполнить с SQL</translation>
    </message>
    <message>
        <location filename="graphwindow.ui" line="525"/>
        <source>Execute</source>
        <translation>Запустить</translation>
    </message>
</context>
</TS>
