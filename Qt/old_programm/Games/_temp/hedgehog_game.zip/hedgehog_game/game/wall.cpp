#include "wall.h"

Wall::Wall(QWidget *parent): Block(parent) {
  animation(":/game/pics/wall.gif");
}
