#include "../../../../../src/nfc/qnearfieldsharemanager_p.h"
