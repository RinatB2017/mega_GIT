<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="es_AR">
<context>
    <name>PreviewDialog</name>
    <message>
        <source>Print Preview</source>
        <translation type="unfinished">Vista Previa</translation>
    </message>
    <message>
        <source>Zoom in</source>
        <translation type="unfinished">Agrandar</translation>
    </message>
    <message>
        <source>Zoom out</source>
        <translation type="unfinished">Achicar</translation>
    </message>
    <message>
        <source>Print</source>
        <translation type="unfinished">Imprimir</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation type="obsolete">&amp;Exportar</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Report Definition Not Found</source>
        <translation type="unfinished">Definición de reporte no encontrada</translation>
    </message>
    <message>
        <source>The report definition for this report, &quot;%1&quot; cannot be found.
Please contact your Systems Administrator and report this issue.</source>
        <translation type="unfinished">La definicón para este reporte,-&quot;%1&quot; no puede ser encontrada.
Por favor contacte con su administrador y reporte esta falla.</translation>
    </message>
    <message>
        <source>Unknown Error</source>
        <translation type="unfinished">Error desconocido</translation>
    </message>
    <message>
        <source>An unknown error was encountered while processing your request.
Please contact your Systems Administrator and report this issue.</source>
        <translation type="unfinished">Un error desconocido ha sido encontrado mientras procesaba tu petición.
Por favor contacte a su administrador y reporte esta falla.</translation>
    </message>
</context>
</TS>
