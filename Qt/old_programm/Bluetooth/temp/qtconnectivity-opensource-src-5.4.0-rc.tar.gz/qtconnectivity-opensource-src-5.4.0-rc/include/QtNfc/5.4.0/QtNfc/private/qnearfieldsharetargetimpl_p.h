#include "../../../../../src/nfc/qnearfieldsharetargetimpl_p.h"
