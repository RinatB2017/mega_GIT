#include "cloudhelp.h"

CloudHelp::CloudHelp() {
  animation(":/help/pics/hotCell.gif", true);
}
