#include "../../../../../src/nfc/qnearfieldtarget_p.h"
