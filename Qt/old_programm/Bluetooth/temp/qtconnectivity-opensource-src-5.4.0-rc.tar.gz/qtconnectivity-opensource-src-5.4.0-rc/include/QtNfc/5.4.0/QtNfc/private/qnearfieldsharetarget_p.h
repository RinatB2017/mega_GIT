#include "../../../../../src/nfc/qnearfieldsharetarget_p.h"
