#ifndef CLOUDHELP_H
#define CLOUDHELP_H
#include "cloud.h"

class CloudHelp: public Cloud {
  Q_OBJECT
public:
  CloudHelp();
};

#endif // CLOUDHELP_H
