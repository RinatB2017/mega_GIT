#include "../../../../../src/nfc/qnearfieldtarget_emulator_p.h"
