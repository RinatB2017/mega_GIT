#include "../../src/bluetooth/qbluetoothdeviceinfo.h"
