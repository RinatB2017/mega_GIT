#include "../../../../../src/nfc/qnearfieldmanagerimpl_p.h"
